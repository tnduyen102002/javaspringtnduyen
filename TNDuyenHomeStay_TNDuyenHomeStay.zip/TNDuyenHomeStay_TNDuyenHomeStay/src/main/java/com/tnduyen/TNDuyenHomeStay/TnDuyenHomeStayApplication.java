package com.tnduyen.TNDuyenHomeStay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TnDuyenHomeStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TnDuyenHomeStayApplication.class, args);
	}

}
