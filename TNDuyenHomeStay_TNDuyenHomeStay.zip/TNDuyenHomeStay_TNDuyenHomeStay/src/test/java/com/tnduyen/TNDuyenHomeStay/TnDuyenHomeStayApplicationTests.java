package com.tnduyen.TNDuyenHomeStay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnDuyenHomeStayApplicationTests {

	@Test
	void contextLoads() {
	}

}
